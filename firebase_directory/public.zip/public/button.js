var button = document.getElementById("login");

button.onclick = function (){
     location.href = "./login.html";
};